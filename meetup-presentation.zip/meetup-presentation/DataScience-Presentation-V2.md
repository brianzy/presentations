When is simulation better than analysis?
========================================================
author: Roy W. Wilson
date: March 2017
autosize: true



What about moi? (1/13)
========================================================

- Undergraduate majors in Mathematics and in Philosophy
- Masters degrees in Mathematics and in Computer Science
- Used mathematics, statistics, simulation on SCI project (Intell-related) 
- Graduate minor in statistics 
    - Non-parametrics, SEM, Experimental and Quasi-Experimental Design


A Minimal Social Network (2/13)
=========================================================

Suppose two people ($x$ and $y$) meet to work on a problem knowing nothing about each other. After brief discussion, it seems that $x$ knows more than $y$ about something that seems relevant to the problem. A relationship of dominance might then form between $x$ and $y$, a situation that can be represented as $xDy$. For simplicity, suppose that: if $xDy$, then $ydx$ where $d$ indicates that $y$ defers to $x$, and; once a social relationship forms between $x$ and $y$, it remains through the remaining sequence of interactions. 

A model of a larger network (3/13)
========================================================

This initial DISCRETE state of the social situation can be pictured as the 4 x 4 sociomatrix $R$:


```
     [,1] [,2] [,3] [,4]
[1,] "u"  "u"  "u"  "u" 
[2,] "u"  "u"  "u"  "u" 
[3,] "u"  "u"  "u"  "u" 
[4,] "u"  "u"  "u"  "u" 
```
where 'u' (for 'undefined') indicates that there are no task-related social relationships are (yet) defined.

A Formal Structure - Part 1 (4/13)
========================================================

Now, suppose that, after some discussion, it seems that agent 4 has (or seems to have) more task-relevant knowledge than the others. At least for a while, the other three agents may defer to agent 4 when trying to define (or carry out) the task, a situation formally represented as:


```
     [,1] [,2] [,3] [,4]
[1,] "u"  "u"  "u"  "d" 
[2,] "u"  "u"  "u"  "d" 
[3,] "u"  "u"  "u"  "d" 
[4,] "D"  "D"  "D"  "u" 
```

The Formal Structure - Part 2 (5/13)
========================================================

If at time $i$, a pair of members interact, a new social relation (D or d) MAY form. If it does, this generates $R[i+1]$ and, with "enough"" interactions, say $K$, every off-diagonal entry of $R[K]$ will be either d or D. For example,


```
     [,1] [,2] [,3] [,4]
[1,] "u"  "d"  "D"  "D" 
[2,] "D"  "u"  "d"  "D" 
[3,] "d"  "D"  "u"  "d" 
[4,] "d"  "d"  "D"  "u" 
```

SO WHAT? (6/13)
=========================================================

Suppose that it was, in fact, a simulation that transformed $R[0]$ to $R[6]$. Might there be some other method not involving simulation that is simpler and/or quicker? It depends.

First: Unwind each R[i] (7/13)
========================================================


```
     0 :  u u u u u u u u u u u u u u u u 

     1 :  u u u D u u u u u u u u d u u u 

     2 :  u d u D D u u u u u u u d u u u 

     3 :  u d D D D u u u d u u u d u u u 

     4 :  u d D D D u d u d D u u d u u u 

     5 :  u d D D D u d D d D u u d d u u 

     6 :  u d D D D u d D d D u d d d D u 
```

Predicting a final state from an initial state (8/12)
========================================================

The Incompressibility Criterion "formulates the unpredictability of a given state from knowledge of the rule and initial state ... — but of course, not [emphasis added] of step $n + 1$ relative to step $n$, since this is perfectly … determined." (Huneman, 2008, p. 600)

An object $o$ is INCOMPRESSIBLE if $C(o)$, the length of a compressed version of $o$ obtained via some real-world compressor $C$, and the length of $o$, denoted $len(o)$, are related as follows (where $C(o)$ and $len(o)$ are defined in terms of bits): $C(o)$ > $len(o)$ (Li and Vitanyi 2008, p. 116).

Using the Incompressibility Criterion (9/12)
====================================================

Formal inference about COMPRESSIBILITY (and, therefore, INCOMPRESSIBILITY) is based on Kolmogorov complexity (which is related to, but distinct from, Shannon complexity). The Kolmogorov complexity function is not itself computable, but it can be approximated by real-world compressors such as zip, bzip, and pmz. Cilibrasi provides such an approximator: the Normalized Compression Distance function NCD() (<http://complearn.org/ncd.html>).

Test for incompressibility (10/12)
========================================================

The first row of the following table identifies each member of the ${S[i]}$ sequence. Row C shows the number of bits in the compressed version of each $S[i]$. Row NCD shows NCD($S[i-1]$,$S[i]$), where $i$ = 1 ... 6.


```
                                      
I      0    1    2    3    4    5    6
C     88  136  144  144  176  192  168
NCD <NA> 0.53 0.32 0.37 0.48 0.44 0.32
```

Interpreting the previous table (11/12)
=======================================================================

For $i$ > 0, $S[i]$ is an incompressible sequence of characters because $C(S[i])$ > 128 = $len(S[i])$ = 128 = 16 * 8. Typically 0 ≤ $NCD(a, b)$ < 1.1. Smaller $NCD$ values indicate greater similarity between $a$ and $b$. 

The first state transition from $R[0]$ to $R[1]$ generates more unpredictability than does any succeeding state transition. Yet, dissimilarities accumulate: $NCD(S[0], S[6]) = 0.64$ > $NCD(S[i],S[i+1])$ for all $i$ > 1.  

So, a (hypothetical) agent-based simulation transforms the COMPRESSIBLE macrostate $R[0]$ into the INCOMPRESSIBLE macrostate $R[6]$. 

Summary (12/13)
========================================================

The value 0.64 quantifies the unpredictability of $R[6]$ given $R[0]$ (Huneman 2008, p. 600). A different set of rules/representations might generate a different sequence of network states that might be "better" than those given above in the sense that it might be "easier" to get something equivalent to $R[6]$ starting with something equivalent to $R[0]$, perhaps doing so in fewer steps. In general, however, larger values of NCD(initial,final) suggest greater difficulty in finding a "easier" approach to getting from an initial to a terminal state.

Addenda (13/13)
=======================================================

The above is based on the 2007 paper <http://jasss.soc.surrey.ac.uk/13/3/8.html>. There, dyadic social relations form as a probabilistic function of agent characteristics and network structure. 

In one of the "real" worlds, we might monitor a certain social network, and note it's evolution, perhaps to profit from such empirical knowledge. One might then calculate $NCD(S[i], S[j])$, which would provide a measure of the difficulty of trying to predict (by whatever means, including data science) whether a given network might evolve from some state $i$ to a desired state $j$. 
